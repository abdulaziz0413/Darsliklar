﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using Telegram.Bot;
using Telegram.Bot.Exceptions;
using Telegram.Bot.Polling;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types.ReplyMarkups;

namespace telegram_bot.TelegramBotFolder
{
    public class TelegramBotHandler
    {
        private string BotToken;
        public bool isClickedCommand= false;
        public bool isPostDesc = false;
        public bool chanelEditor = false;
        public bool mediaEditor =false;
        public bool textEditor = false;
        public bool inCorrectLink = false;
        public string chanelName = "";
        public dynamic Video;
        public dynamic Photo;
        public dynamic Link;
        public dynamic PostDescription;
        
        public string Token { get; set; }
        public TelegramBotHandler(string token)
        {
            BotToken = token;
        }
        public async Task BotHandle()
        {
            var botClient = new TelegramBotClient(BotToken);

            using CancellationTokenSource cts = new CancellationTokenSource();
            ReceiverOptions receiverOptions = new ReceiverOptions()
            {
                AllowedUpdates = Array.Empty<UpdateType>() 
            };

            botClient.StartReceiving(
                updateHandler: HandleUpdateAsync,
                pollingErrorHandler: HandlePollingErrorAsync,
                receiverOptions: receiverOptions,
                cancellationToken: cts.Token
            );
            var me = await botClient.GetMeAsync();

            Console.WriteLine($"Start listening for @{me.Username}");
            Console.ReadLine();

            // Send cancellation request to stop bot
            cts.Cancel();
        }
        public async Task HandleUpdateAsync(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
        {
            Message message;
            string messageText = "";
            if (update.Message != null)
            {
                message = update.Message;
            }
            else
            {
                return;
            }

            if (message.Text != null)
            {
                messageText = message.Text;
            }
            var chatId = message.Chat.Id;
            if (isClickedCommand || messageText == "Back")
            {
                chanelName = messageText;
                isClickedCommand = false;
                var replyKeyboard = new ReplyKeyboardMarkup
                    (new[]
                    {
                        new KeyboardButton("Send Post"),
                        new KeyboardButton("Edit Post"),
                        new KeyboardButton("Post view"),

                    }
                    )
                {
                    ResizeKeyboard = true
                };

                await botClient.SendTextMessageAsync
                    (
                    chatId: chatId,
                    text: "Send your post",
                    cancellationToken: cancellationToken,
                    replyMarkup: replyKeyboard);
                isPostDesc = true;
                return;
            }
            if (messageText == "Edit Post")
            {
                var replyKeyboard = new ReplyKeyboardMarkup
                   (new[]
                   {
                       new KeyboardButton("Edit channel"),
                       new KeyboardButton("Edit text"),
                       new KeyboardButton("Edit media"),
                       new KeyboardButton("Back"),

                   }
                   )
                {
                    ResizeKeyboard = true
                };
                await botClient.SendTextMessageAsync(
                    chatId: chanelName,
                    text: "Send your post",
                    cancellationToken: cancellationToken);

            }
            if (messageText == "Send Post")
            {
                try
                {
                    string post = $"{chanelName}\n\n{PostDescription}\n\n{Link}";
                    inCorrectLink = true;
                    return;
                }
                catch
                {
                    await botClient.SendTextMessageAsync(
                        chatId: chatId,
                        text: "Link incorrect!",
                        cancellationToken: cancellationToken
                        );
                }
                finally
                {
                    if (inCorrectLink)
                    {
                        await botClient.SendTextMessageAsync(
                           chatId: chatId,
                           text: "The post has been sent!",
                           cancellationToken: cancellationToken
                           );
                    }
                }
            }
            if (messageText == "Post view")
            {
                string post = $"{chanelName}\n\n{PostDescription}\n\n{Link}";
                await botClient.SendTextMessageAsync(
                    chatId: chatId,
                    text: post,
                    cancellationToken: cancellationToken
                    );
                return;
            }
            if (messageText == "Edit channel")
            {
                chanelEditor = true;
                await botClient.SendTextMessageAsync(
                    chatId: chatId,
                    text: "Enter Chanel Name",
                    cancellationToken: cancellationToken
                    );
                return;
            }
            if (chanelEditor == true && messageText != "")
            {
                chanelName = messageText;
                chanelEditor = false;
                return;
            }
            if (messageText == "Edit text")
            {
                textEditor = true;
                await botClient.SendTextMessageAsync(
                    chatId: chatId,
                    text: "Enter Post Text",
                    cancellationToken: cancellationToken
                    );
                return;
            }
            if (textEditor == true && messageText != "")
            {
                PostDescription = messageText;
                textEditor = false;
                return;
            }
            if (messageText == "Edit media")
            {
                mediaEditor = true;
                await botClient.SendTextMessageAsync(
                    chatId: chatId,
                    text: "Send Post Media",
                    cancellationToken: cancellationToken
                    );
                return;
            }
            if (mediaEditor == true && MessageType.Video == message.Type)
            {
                Video = message;
                mediaEditor = false;
                return;
            }
            if (messageText == "/create_post")
            {
                await botClient.SendTextMessageAsync(
                    chatId: chatId,
                    text: "Please enter chanel name(username)",
                    cancellationToken: cancellationToken);
                isClickedCommand = true;
                return;
            }
            if (messageText.StartsWith("https://"))
            {
                Link = message.Text;
            }
            else if (isPostDesc)
            {
                PostDescription = messageText;
            }
            else if (message.Type == MessageType.Video)
            {
                Video = message.Video;
            }
            else if (message.Type == MessageType.Photo)
            {
                Photo = message.Photo;
            }
            if (messageText == "/start")
            {
                await botClient.SendTextMessageAsync(
                    chatId: chatId,
                    text: "Post yaratish uchun /create postni bosing",
                    cancellationToken: cancellationToken);
                isClickedCommand = false;
                return;
            }
        }




          

       

        public Task HandlePollingErrorAsync(ITelegramBotClient botClient, Exception exception, CancellationToken cancellationToken)
        {
            var ErrorMessage = exception switch
            {
                ApiRequestException apiRequestException
                    => $"Telegram API Error:\n[{apiRequestException.ErrorCode}]\n{apiRequestException.Message}",
                _ => exception.ToString()
            };

            Console.WriteLine(ErrorMessage);
            return Task.CompletedTask;
        }
    }
}
